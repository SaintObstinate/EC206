/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.model.Cliente;
import br.inatel.model.Funcionario;
import br.inatel.model.Medicamento;
import br.inatel.model.Venda;
import java.util.ArrayList;

/**
 *
 * @author Bruno Balestra
 */
public class DAO {
    
    private ArrayList<Funcionario> funcionarios; //funcionarios salvos
    private ArrayList<Medicamento> medicamentos;// medicamentos salvos
    private ArrayList<Cliente> clientes;
    private ArrayList<Venda> venda;
    private Funcionario logado; 
    private int editar;

    public int getEditar() {
        return editar;
    }

    public void setEditar(int editar) {
        this.editar = editar;
    }

    public Funcionario getLogado() {
        return logado;
    }

    public void setLogado(Funcionario logado) {
        this.logado = logado;
    }
    private static DAO instance = null;
    
     private DAO() {
        this.editar = -1;
        funcionarios = new ArrayList();
        medicamentos = new ArrayList();
        clientes = new ArrayList();
        venda = new ArrayList();
        logado = new Funcionario();
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public ArrayList<Medicamento> getMedicamentos() {
        return medicamentos;
    }

    public void setMedicamentos(ArrayList<Medicamento> medicamentos) {
        this.medicamentos = medicamentos;
    }
    
    public ArrayList<Venda> getVenda() {
        return venda;
    }

    public void setVenda(ArrayList<Venda> venda) {
        this.venda = venda;
    }
    
    public static DAO getInstance() {
          if (instance == null) {
        
            instance = new DAO();
            
        }
        return instance;
        }
    

    public ArrayList<Funcionario> getFuncionarios() {
        return funcionarios;
    }
    
    public void CadastraFunc(Funcionario a){ // cadastra funcionarios colocando no arraylist
        funcionarios.add(a);
    }
    public void CadastraMed(Medicamento a){// cadastra medicamentos colocando no arraylist
        medicamentos.add(a);
    }
    public void CadastraCli(Cliente a){// cadastra clientes colocando no arraylist
        clientes.add(a);
    }
    public void CadastraVen(Venda a){
        venda.add(a);
    }
    public void EditarCli(int a, Cliente b){
        clientes.get(a).setNome(b.getNome());
        clientes.get(a).setCpf(b.getCpf());
        clientes.get(a).setIdade(b.getIdade());
        clientes.get(a).setId(b.getId());
    }
    public void EditarFunc(int a, Funcionario b){
        funcionarios.get(a).setNome(b.getNome());
        funcionarios.get(a).setLogin(b.getLogin());
        funcionarios.get(a).setSenha(b.getSenha());
        funcionarios.get(a).setId(b.getId());
    }
    public void EditarMed(int a, Medicamento b){
        medicamentos.get(a).setNome(b.getNome());
        medicamentos.get(a).setTipo(b.getTipo());
        medicamentos.get(a).setValor(b.getValor());
    }
    
    public void EditarVen(int a, Venda b){
        venda.get(a).setCliente(b.getCliente());
        venda.get(a).setMedicamento(b.getMedicamento());
        venda.get(a).setPreco(b.getValor());
        venda.get(a).setQuantidade(b.getQuantidade());
    }
    
    public boolean procuraUser(String user, String pass ){
        for(int i = 0; i<funcionarios.size(); i++){
            if(funcionarios.get(i).getLogin().equals(user)&& funcionarios.get(i).getSenha().equals(pass)){
                logado.setNome(user); //seleciona o nome do usuário logado
                return true;
            }
        }
        return false;
    }
   
    public Funcionario editUser(String nome){
        Funcionario aux = new Funcionario();
        aux.setNome("");
        
        for(int i = 0; i<funcionarios.size(); i++){
        if(funcionarios.get(i).getNome().equals(nome)){
            aux = funcionarios.get(i);
            return aux;
           }
        }
        return null;
    }
    
    public void test(){
        for(int i =0; i<funcionarios.size(); i++){
            System.out.println(funcionarios.get(i).getNome());
        }
    }
   
}
