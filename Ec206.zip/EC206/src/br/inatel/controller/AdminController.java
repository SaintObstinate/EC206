/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.model.Funcionario;
import br.inatel.view.TelaAdmin;

/**
 *
 * @author cliente
 */
public class AdminController {
    private static AdminController instance = null;
    TelaAdmin telaAdmin;
    DAO aux;
    private AdminController() {
    }
    public static AdminController getInstance() {
          if (instance == null) {
        
            instance = new AdminController();
        }
        return instance;
        }
    
     public void criarJanela() { //janela nivel adm
        telaAdmin= new TelaAdmin();
        telaAdmin.setVisible(true);
        telaAdmin.setLocationRelativeTo(null);
    }
      public void logout() {
          
        telaAdmin= new TelaAdmin();
        telaAdmin.setVisible(true);
        telaAdmin.setLocationRelativeTo(null);
    }
     public void telaMedicamento(){ //janela list medicamento
         //telaAdmin.close();
         MedicamentoController telaMed = MedicamentoController.getInstance();
         telaMed.criarJanela();
     }
     public void telaFuncionario(){ // janela list funcionario
         //telaAdmin.close();
         FuncionarioController telaFunc = FuncionarioController.getInstance();
         telaFunc.criarJanela();
     }
      public void telaClientes(){ // janela list clientes
         //telaAdmin.close();
         ClienteController telaFunc = ClienteController.getInstance();
         telaFunc.criarJanela();
     }
      public void telaVendas(){ // janela list clientes
         //telaAdmin.close();
         VendaController telaFunc = VendaController.getInstance();
         telaFunc.criarJanela();
     }
       public void cadastrarFunc( String nome,String login, String senha){
        Funcionario x = new Funcionario();
        x.setNome(nome);
        x.setLogin(login);
        x.setSenha(senha);
        DAO aux = DAO.getInstance();
        aux.CadastraFunc(x);
    }
       public void editarFunc (String nome, String login, String senha, int id){
        Funcionario x = new Funcionario();
        x.setNome(nome);
        x.setLogin(login);
        x.setSenha(senha);
        DAO aux = DAO.getInstance();
        aux.EditarFunc(id, x);
    }
}
