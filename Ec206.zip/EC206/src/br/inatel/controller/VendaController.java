/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.model.Venda;
import br.inatel.view.TelaCRUDVenda;
import br.inatel.view.TelaListVenda;

/**
 *
 * @author bales
 */
public class VendaController {
     private static VendaController instance = null;
    TelaListVenda telaVen;
    TelaCRUDVenda telaCrud;
    private VendaController() {
    }
    public static VendaController getInstance() {
          if (instance == null) {
        
            instance = new VendaController();
        }
        return instance;
    }
    
    public void criarJanela() {
        telaVen = new TelaListVenda();
        telaVen.setVisible(true);
        telaVen.setLocationRelativeTo(null);
    }
    public void telaCrudVenda(){
        
        telaCrud = new TelaCRUDVenda();
        telaCrud.setVisible(true);
        telaCrud.setLocationRelativeTo(null);
    }
    public void voltarTelaVenda(){
        telaCrud.dispose();
        telaVen.setVisible(true);
        telaVen.setLocationRelativeTo(null);
    }
    public void cadastrarVenda(int cliente, int medicamento, int qtd, float valor){
        Venda x = new Venda();
        x.setCliente(cliente);
        x.setMedicamento(medicamento);
        x.setQuantidade(qtd);
        x.setPreco(valor);
        DAO aux = DAO.getInstance();
        aux.CadastraVen(x);
        criarJanela();
    }
    public void editarVenda(int cliente, int medicamento, int qtd, float valor,int id){
        Venda x = new Venda();
        x.setCliente(cliente);
        x.setMedicamento(medicamento);
        x.setQuantidade(qtd);
        x.setPreco(valor);
        DAO aux = DAO.getInstance();
        aux.EditarVen(id,x);
    }
}
