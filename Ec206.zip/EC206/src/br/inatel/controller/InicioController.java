/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;


import br.inatel.view.TelaLogin;
import javax.swing.JOptionPane;

/**
 *
 * @author cliente
 */
public class InicioController {
    private static InicioController instance = null;
    TelaLogin telaInicio;
    DAO aux = DAO.getInstance();
    private InicioController() {
    }
    public static InicioController getInstance() {
          if (instance == null) {
        
            instance = new InicioController();
        }
        return instance;
        }
    
    public void criarJanela() {
     
        telaInicio= new TelaLogin();
        telaInicio.setVisible(true);
        telaInicio.setLocationRelativeTo(null);   
    }
    public void logout() {
        telaInicio= new TelaLogin();
        telaInicio.setVisible(true);
        telaInicio.setLocationRelativeTo(null);   
    }
    public void telaAdmin(){
         telaInicio.close();
         AdminController telaAdmin = AdminController.getInstance();
         telaAdmin.criarJanela();

    }
    public void telaFuncionario(){
         telaInicio.close();
         FuncionarioController telaFunc = FuncionarioController.getInstance();
         telaFunc.telaFunc();

    }
    public void validaLogin(){
        String user;
        String pass;
        
        user = telaInicio.retornaUser();
        pass = telaInicio.retornaPass();
        
        if(user.equals("admin")&& pass.equals("admin")){
            telaAdmin();
            
        }else if(aux.procuraUser(user, pass)){
            telaFuncionario();
        }
        else JOptionPane.showMessageDialog(telaInicio, "Usuario e/ou senha incorretos!", "Erro!", JOptionPane.WARNING_MESSAGE);
    }
}
