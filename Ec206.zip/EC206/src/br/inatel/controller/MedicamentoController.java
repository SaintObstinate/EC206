/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.model.Medicamento;
import br.inatel.view.TelaCRUDMedicamento;
import br.inatel.view.TelaListMedicamento;

/**
 *
 * @author bales
 */
public class MedicamentoController {
     private static MedicamentoController instance = null;
    TelaListMedicamento telaMed;
    TelaCRUDMedicamento telaCrud;
    private MedicamentoController() {
    }
    public static MedicamentoController getInstance() {
          if (instance == null) {
        
            instance = new MedicamentoController();
        }
        return instance;
        }
    
    public void criarJanela() {
        telaMed= new TelaListMedicamento();
        telaMed.setVisible(true);
        telaMed.setLocationRelativeTo(null);
    }
    public void telaCrudMed(){
        
        telaCrud = new TelaCRUDMedicamento();
        telaCrud.setVisible(true);
        telaCrud.setLocationRelativeTo(null);
    }
    public void voltarTelaMed(){
        telaCrud.dispose();
        telaMed.setVisible(true);
        telaMed.setLocationRelativeTo(null);
    }
    public void cadastrarMed(String nome, String tipo, float valor){
        Medicamento x = new Medicamento();
        x.setNome(nome);
        x.setTipo(tipo);
        x.setValor(valor);
        DAO aux = DAO.getInstance();
        aux.CadastraMed(x);
        criarJanela();
    }
    public void editarMed (String nome, String tipo, float valor, int id){
        Medicamento x = new Medicamento();
        x.setNome(nome);
        x.setTipo(tipo);
        x.setValor(valor);
        DAO aux = DAO.getInstance();
        aux.EditarMed(id, x);
    }
}
