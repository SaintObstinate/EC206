/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.model.Cliente;
import br.inatel.view.TelaCRUDCliente;
import br.inatel.view.TelaListClientes;
import br.inatel.view.TelaListMedicamento;

/**
 *
 * @author bales
 */
public class ClienteController {
     private static ClienteController instance = null;
    TelaListClientes telaCli;
    TelaCRUDCliente telaCrud;
    private ClienteController() {
    }
    public static ClienteController getInstance() {
          if (instance == null) {
        
            instance = new ClienteController();
        }
        return instance;
        }
    
    public void criarJanela() {
        telaCli= new TelaListClientes();
        telaCli.setVisible(true);
        telaCli.setLocationRelativeTo(null);  
    }
   
    public void telaCadastro(){ // abrir tela cadastro
        telaCrud = new TelaCRUDCliente();
        telaCrud.setVisible(true);
        telaCrud.setLocationRelativeTo(null);
    }
    public void cadastroCliente(String nome, String cpf, int idade){
        Cliente aux = new Cliente();
        aux.setNome(nome);
        aux.setIdade(idade);
        aux.setCpf(cpf);
        DAO x = DAO.getInstance();
        x.CadastraCli(aux);
    }
    
    public void editarCliente(String nome, String cpf, int idade, int id){
        Cliente aux = new Cliente();
        aux.setNome(nome);
        aux.setIdade(idade);
        aux.setCpf(cpf);
        DAO x = DAO.getInstance();
        x.EditarCli(id, aux);
    }
}
