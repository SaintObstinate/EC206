/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.view.TelaCRUDMedicamento;

/**
 *
 * @author bales
 */
public class MedicamentoController {
     private static MedicamentoController instance = null;
    TelaCRUDMedicamento telaMed;
    private MedicamentoController() {
    }
    public static MedicamentoController getInstance() {
          if (instance == null) {
        
            instance = new MedicamentoController();
        }
        return instance;
        }
    
    public void criarJanela() {
        telaMed= new TelaCRUDMedicamento();
        telaMed.setVisible(true);
        telaMed.setLocationRelativeTo(null);
        
     
        
    }
}
