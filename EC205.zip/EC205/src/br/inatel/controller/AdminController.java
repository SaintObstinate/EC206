/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.view.TelaAdmin;

/**
 *
 * @author cliente
 */
public class AdminController {
    private static AdminController instance = null;
    TelaAdmin telaAdmin;
    private AdminController() {
    }
    public static AdminController getInstance() {
          if (instance == null) {
        
            instance = new AdminController();
        }
        return instance;
        }
    
     public void criarJanela() {
       
        
        telaAdmin= new TelaAdmin();
        telaAdmin.setVisible(true);
        telaAdmin.setLocationRelativeTo(null);
    }
     public void telaMedicamento(){
         telaAdmin.close();
         MedicamentoController telaMed = MedicamentoController.getInstance();
         telaMed.criarJanela();
     }
     public void telaFuncionario(){
         telaAdmin.close();
         FuncionarioController telaFunc = FuncionarioController.getInstance();
         telaFunc.criarJanela();
     }
      public void telaClientes(){
         telaAdmin.close();
         ClienteController telaFunc = ClienteController.getInstance();
         telaFunc.criarJanela();
     }
}
