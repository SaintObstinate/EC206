/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.view.TelaCRUDFuncionario;
import br.inatel.view.TelaListFuncionarios;

/**
 *
 * @author bales
 */
public class FuncionarioController {
     private static FuncionarioController instance = null;
    TelaListFuncionarios telaFunc;
    TelaCRUDFuncionario telaCrud;
    private FuncionarioController() {
    }
    public static FuncionarioController getInstance() {
          if (instance == null) {
        
            instance = new FuncionarioController();
        }
        return instance;
        }
    
    public void criarJanela() {
        telaFunc= new TelaListFuncionarios();
        telaFunc.setVisible(true);
        telaFunc.setLocationRelativeTo(null);
        
    }
    public void telaCrudFunc(){
        telaFunc.dispose();
        telaCrud = new TelaCRUDFuncionario();
        telaCrud.setVisible(true);
        telaCrud.setLocationRelativeTo(null);
    }
    public void voltarTelaFunc(){
        telaCrud.dispose();;
        telaFunc.setVisible(true);
        telaFunc.setLocationRelativeTo(null);
    }
}
