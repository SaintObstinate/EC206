/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.controller;

import br.inatel.view.TelaCRUDClientes;
import br.inatel.view.TelaCRUDMedicamento;

/**
 *
 * @author bales
 */
public class ClienteController {
     private static ClienteController instance = null;
    TelaCRUDClientes telaCli;
    private ClienteController() {
    }
    public static ClienteController getInstance() {
          if (instance == null) {
        
            instance = new ClienteController();
        }
        return instance;
        }
    
    public void criarJanela() {
        telaCli= new TelaCRUDClientes();
        telaCli.setVisible(true);
        telaCli.setLocationRelativeTo(null);
        
     
        
    }
}
